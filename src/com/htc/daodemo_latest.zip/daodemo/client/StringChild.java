package com.htc.daodemo.client;

public final class StringChild  {
private  final String value;

public StringChild(String value)
{
	this.value=value;
}

public String getValue() {
	return value;
}


}
