package com.htc.springsecurityjwt.models;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;



@Entity

public class Role {
	@Id
	@GeneratedValue
	private Long Id;
	private String name;
	private String description;
	@ManyToMany(fetch = FetchType.EAGER)
	private Set<Privilege> privileges ;
	public Long getRoleId() {
		return Id;
	}
	public void setRoleId(Long roleId) {
		this.Id = roleId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Set<Privilege> getPrivileges() {
		return privileges;
	}
	public void setPrivileges(Set<Privilege> privileges) {
		this.privileges = privileges;
	}
}