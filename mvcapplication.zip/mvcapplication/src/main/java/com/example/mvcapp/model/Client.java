package com.example.mvcapp.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Client {
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE)
	private int clientId;
	
	private String firstName;
	
	private String lastName;
	
	private String phone;
	
	private String street;
	
	private String city;
	
	private String state;
	
	private int zipCode;
	
	private String password;
	
	
	@OneToMany(mappedBy="client")
	private Set<Appointment> clientAppointmentSet;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "userRoles", joinColumns = @JoinColumn(name = "clientId"), inverseJoinColumns = @JoinColumn(name = "roleid"))
	Set<Roles> roles;

	
	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public Client(String firstName, String lastName, String phone, String street, String city, String state,
			int zipCode, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.password = password;
	}



	public Client(String phone, String password) {
		super();
		this.phone = phone;
		this.password = password;
	}



	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<Appointment> getClientAppointmentSet() {
		return clientAppointmentSet;
	}

	public void setClientAppointmentSet(Set<Appointment> clientAppointmentSet) {
		this.clientAppointmentSet = clientAppointmentSet;
	}

	public Set<Roles> getRoles() {
		return roles;
	}

	public void setRoles(Set<Roles> roles) {
		this.roles = roles;
	}



	@Override
	public String toString() {
		return "Client [clientId=" + clientId + ", firstName=" + firstName + ", lastName=" + lastName + ", phone="
				+ phone + ", street=" + street + ", city=" + city + ", state=" + state + ", zipCode=" + zipCode
				+ ", password=" + password + ", clientAppointmentSet=" + clientAppointmentSet
				+ ", roles=" + roles + "]";
	}
	
	
}
