package com.example.mvcapp.propertybinder;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class CustomDateFormatter extends PropertyEditorSupport {
	
	@Override
	public void setAsText(String value) throws IllegalArgumentException {
		System.out.println(value + " value<========================");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println(formatter + " formatter <========================");
		LocalDate dateTime = LocalDate.parse(value, formatter);
		System.out.println(dateTime + " dateTime<========================");
		setValue(dateTime);
	} 
}
