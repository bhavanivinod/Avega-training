package com.example.mvcapp.controller;

import java.security.Principal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.mvcapp.dto.AppointmentDto;
import com.example.mvcapp.dto.ClientDto;
import com.example.mvcapp.exception.ClientAppoinmentException;
import com.example.mvcapp.model.Client;
import com.example.mvcapp.model.Lawyer;
import com.example.mvcapp.model.Roles;
import com.example.mvcapp.propertybinder.CustomDateFormatter;
import com.example.mvcapp.serviceImpl.ClientUserService;

@Controller
public class HomeController {

	Logger log = Logger.getLogger(HomeController.class.getName());
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(LocalDate.class, "appointmentDate", new CustomDateFormatter());
	}
	
	@Autowired
	ClientUserService clientUserService;
	
	 @Autowired
	 RestTemplate restTemplate;
	 
	@RequestMapping(value="/access-denied", method = RequestMethod.GET)
	public String accessDenied() {
		return "accessDenied";
	}
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public String home(Model model) {
//		model.addAttribute("credentials", new Client());
		return "home";
	}
	
	@RequestMapping(value="/login",  method = RequestMethod.GET)
	public String loginPage(Model model) {
		model.addAttribute("credentials",new Client());
		return "loginPage";
	}
	
	@RequestMapping(value="/home", method = RequestMethod.GET)
	public String successLogin( Authentication authentication) {
		System.out.println(authentication.getAuthorities());
		return "home";
	}
	
	@RequestMapping(value="/admin/adduser", method = RequestMethod.GET)
	public String addUser(Model model,   @Validated ClientDto clientDto, BindingResult results,
			RedirectAttributes redirectAttributes) {
//		Client client = clientUserService.dtoToDaoConverter(clientDto);
		
		model.addAttribute("user", new ClientDto());
		return "addUser";
	}
	
	@RequestMapping(value="/admin/submitUser", method = RequestMethod.POST)
	public String submitUser(Model model,   @Validated ClientDto clientDto, BindingResult results,
			RedirectAttributes redirectAttributes) {
		
		model.addAttribute("user", clientDto);
		if (results.hasErrors()) {
			return "addUser";
		}
		if(clientDto.getRoleName().equals("CLIENT") || clientDto.getRoleName().equals("ADMIN")) {
			Client client = clientUserService.dtoToDaoConverter(clientDto);
			clientUserService.addUser(client);
		} else {
			Lawyer lawyer = clientUserService.dtoToDaoConverterLawyer(clientDto);
			clientUserService.addLawyer(lawyer);
		}
		
		String sucessMessage = "User added Successfully!";
		redirectAttributes.addFlashAttribute("userAdded", sucessMessage);
		return "redirect:successPage";
	}
	
	@RequestMapping(value="/admin/successPage",  method = RequestMethod.GET)
	public String successPage() {
		return "successPage";
	}
	
	@RequestMapping(value="/client/addAppoinment",  method = RequestMethod.GET)
	public String addAppointment(Model model) {
		model.addAttribute("appointment", new AppointmentDto());
		return "addAppointment";
	}
	
	@RequestMapping(value="/client/submitAppointment", method = RequestMethod.POST)
	public String submitAppointment(Model model,   @Validated AppointmentDto appointmentDto, BindingResult results,
			RedirectAttributes redirectAttributes, Principal principal) throws ClientAppoinmentException {
//		Client client = clientUserService.dtoToDaoConverter(clientDto);
		if (results.hasErrors()) {
			return "addAppointment";
		}
		
		String clientPhone = principal.getName();
		boolean appintmentAdded;
		try {
			appintmentAdded = clientUserService.addAppoinment(appointmentDto, clientPhone);
			String sucessMessage = "Appointment added Successfully!";
			if(appintmentAdded)  sucessMessage = "Appointment added Successfully!";
			else sucessMessage = "Appoinment not added!";
			redirectAttributes.addFlashAttribute("userAdded", sucessMessage);
			return "redirect:successPage";
		} catch (ClientAppoinmentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.info("ERROR MESSAGE====> " +  e.getErrorMessages());
		}
		return clientPhone;
	}
	
	@RequestMapping(value="/client/successPage",  method = RequestMethod.GET)
	public String appointmentSuccessPage() {
		return "successPage";
	}
	
//	@RequestMapping(value="/comments-likes")
//	public String getCommentLikesList() {
//		HttpHeaders headers = new HttpHeaders();
//		restTemplate.exchange("http://localhost:8081/getcommentsAndLikes/1/3",HttpMethod.GET, ResponseEntity<T>.class).getBody();
//	}
	
	@RequestMapping(value="test-return-string")
	public String getSampleText(RedirectAttributes redirectAttributes) {
		ResponseEntity<String> fromOutSide  = restTemplate.getForEntity("http://localhost:8081/test-return-string", String.class);
		
		String result = fromOutSide.getBody();
		redirectAttributes.addFlashAttribute("userAdded", result);
		return "redirect:/admin/successPage";
	}
}
