package com.example.mvcapp.dto;

import java.util.Date;

import javax.validation.constraints.Future;

public class AppointmentDto {
	
	@Future
	private Date appointmentDate;
	
	private String lawyerPhone;
	
	private String reason;

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getLawyerPhone() {
		return lawyerPhone;
	}

	public void setLawyerPhone(String lawyerPhone) {
		this.lawyerPhone = lawyerPhone;
	}

	public AppointmentDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AppointmentDto(@Future Date appointmentDate, String lawyerPhone) {
		super();
		this.appointmentDate = appointmentDate;
		this.lawyerPhone = lawyerPhone;
	}
	
	
}
