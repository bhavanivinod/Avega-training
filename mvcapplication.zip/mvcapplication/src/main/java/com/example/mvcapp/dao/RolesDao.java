package com.example.mvcapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.mvcapp.model.Roles;

@Repository
public interface RolesDao extends JpaRepository<Roles, Integer> {

}
