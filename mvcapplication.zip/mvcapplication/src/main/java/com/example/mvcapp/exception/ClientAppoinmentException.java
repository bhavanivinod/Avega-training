package com.example.mvcapp.exception;

public class ClientAppoinmentException extends Exception {
	String errorMessages;

	public ClientAppoinmentException(String errorMessages) {
		super();
		this.errorMessages = errorMessages;
	}

	public String getErrorMessages() {
		return errorMessages;
	}

	public void setErrorMessages(String errorMessages) {
		this.errorMessages = errorMessages;
	}
	
}
