package com.example.mvcapp.dto;

public class SuccessDto<T> {
	int statusCode;
	String statusMessage;
	T body;
	
	public SuccessDto(int statusCode, String statusMessage, T body) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
		this.body = body;
	}
	public SuccessDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public T getBody() {
		return body;
	}
	public void setBody(T body) {
		this.body = body;
	}
	
	
}
