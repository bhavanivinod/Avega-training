package com.example.mvcapp.serviceImpl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mvcapp.dao.AppointmentDao;
import com.example.mvcapp.dao.ClientDao;
import com.example.mvcapp.dao.LawyerDao;
import com.example.mvcapp.dao.RolesDao;
import com.example.mvcapp.dto.AppointmentDto;
import com.example.mvcapp.dto.ClientDto;
import com.example.mvcapp.exception.ClientAppoinmentException;
import com.example.mvcapp.model.Appointment;
import com.example.mvcapp.model.Client;
import com.example.mvcapp.model.Lawyer;
import com.example.mvcapp.model.Roles;

@Service("ClientUserService")
public class ClientUserService {
	@Autowired
	ClientDao clientDao;

	@Autowired
	LawyerDao lawyerDao;
	@Autowired
	RolesDao rolesDao;

	@Autowired
	AppointmentDao appointmentDao;

	public boolean addAppoinment(AppointmentDto appointmentDto, String clientPhone) throws ClientAppoinmentException {
		List<Client> clientData = this.findByPhoneNumber(clientPhone);
		Client client = clientData.get(0);
		List<Lawyer> lawyerData = this.findByLawyerPhoneNumber(appointmentDto.getLawyerPhone());
		if(lawyerData.isEmpty()) {
			throw new ClientAppoinmentException("Lawyer Phone number not available");
		}
		Lawyer lawyer = lawyerData.get(0);
		Appointment appointment = new Appointment(appointmentDto.getAppointmentDate(), lawyer, client, appointmentDto.getReason());
		appointmentDao.save(appointment);
		return true;
	}

	public Lawyer dtoToDaoConverterLawyer(ClientDto clientDto) {
		Lawyer lawyer = new Lawyer(clientDto.getFirstName(), clientDto.getLastName(), clientDto.getPhone(),
				clientDto.getSpecialty());
		return lawyer;
	}

	public Client dtoToDaoConverter(ClientDto clientDto) {
		Client client = new Client(clientDto.getFirstName(), clientDto.getLastName(), clientDto.getPhone(),
				clientDto.getStreet(), clientDto.getCity(), clientDto.getState(), clientDto.getZipCode(),
				clientDto.getPassword());
		int roleId;
		if (clientDto.getRoleName().equals("ADMIN"))
			roleId = 1;
		else if (clientDto.getRoleName().equals("CLIENT"))
			roleId = 2;
		else
			roleId = 3;
		Roles role = this.getRoleById(roleId).get();
		Set<Roles> roles = new HashSet<Roles>();
		roles.add(this.getRoleById(roleId).get());
		client.setRoles(roles);
		return client;
	}

	public boolean addLawyer(Lawyer lawyer) {
		return lawyerDao.save(lawyer) != null;
	}

	public boolean addUser(Client client) {
		return clientDao.save(client) != null;
	}

	public List<Client> findByPhoneNumber(String phone) {
		return clientDao.findByPhone(phone);
	}

	public List<Lawyer> findByLawyerPhoneNumber(String phone) {
		return lawyerDao.findByPhone(phone);
	}

	public Optional<Roles> getRoleById(int id) {
		return rolesDao.findById(id);
	}

}
