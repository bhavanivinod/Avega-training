package com.example.mvcapp.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

@Valid
public class ClientDto {
	@Size(min=2, message="{tileErrorMessage}")
	private String firstName;

	@Size(min=1, message="{tileErrorMessage}")
	private String lastName;

	@Size(min=10, max=10,  message="Phone number should be 10 length")
	private String phone;

	@Size(min=3,  message="Street should be minimum 3 char")
	private String street;

	private String city;

	private String state;

	@NotNull(message= "zipCode may not be empty")
	@Range(min=1, max=999999,   message="zip code should be valid")
	private int zipCode;

	private String password;
	
	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	private String roleName;
	
	private String specialty;

	public ClientDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ClientDto(@Size(min = 2, message = "{tileErrorMessage}") String firstName,
			@Size(min = 1, message = "{tileErrorMessage}") String lastName,
			@Size(min = 10, max = 10, message = "Phone number should be 10 length") String phone,
			@Size(min = 3, message = "Street should be minimum 3 char") String street, String city, String state,
			@NotNull(message = "zipCode may not be empty") @Range(min = 1, max = 999999, message = "zip code should be valid") int zipCode,
			String password, String roleName, String specialty) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.password = password;
		this.roleName = roleName;
		this.specialty = specialty;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Override
	public String toString() {
		return "ClientDto [firstName=" + firstName + ", lastName=" + lastName + ", phone=" + phone + ", street="
				+ street + ", city=" + city + ", state=" + state + ", zipCode=" + zipCode + ", password=" + password
				+ ", roleName=" + roleName + ",specialty=" + specialty + "]";
	}

	
}
