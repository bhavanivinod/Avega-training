/*
 * package com.example.mvcapp.dto;
 * 
 * import java.util.Set;
 * 
 * import com.example.restapp.entity.Comments;
 * 
 * public class CommentAndLikeCount { private Set<Comments> commentList; private
 * int likeCount; public CommentAndLikeCount(Set<Comments> commentList, int
 * likeCount) { super(); this.commentList = commentList; this.likeCount =
 * likeCount; } public Set<Comments> getCommentList() { return commentList; }
 * public void setCommentList(Set<Comments> commentList) { this.commentList =
 * commentList; } public int getLikeCount() { return likeCount; } public void
 * setLikeCount(int likeCount) { this.likeCount = likeCount; }
 * 
 * 
 * 
 * 
 * }
 */
