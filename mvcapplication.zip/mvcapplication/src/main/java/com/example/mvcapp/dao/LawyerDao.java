package com.example.mvcapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.mvcapp.model.Client;
import com.example.mvcapp.model.Lawyer;

@Repository
public interface LawyerDao extends JpaRepository<Lawyer, Integer> {

	List<Lawyer> findByPhone(String phone);

//	Object save(Client client);

}
