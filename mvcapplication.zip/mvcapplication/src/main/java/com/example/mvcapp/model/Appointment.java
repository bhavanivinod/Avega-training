package com.example.mvcapp.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class Appointment {
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE)
	private int appoinmentId;
	
	private Date appointmentDate;
	
	private String reason;
	
	@ManyToOne
	@JoinColumn(name="lawyerId")
	Lawyer lawyer;
	
	@ManyToOne
	@JoinColumn(name="clientId")
	Client client;

	
	
	public Appointment(int appoinmentId, Date appointmentDate, String reason, Lawyer lawyer, Client client) {
		super();
		this.appoinmentId = appoinmentId;
		this.appointmentDate = appointmentDate;
		this.reason = reason;
		this.lawyer = lawyer;
		this.client = client;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Appointment(Date appointmentDate, Lawyer lawyer, Client client) {
		super();
		this.appointmentDate = appointmentDate;
		this.lawyer = lawyer;
		this.client = client;
	}
	
	public Appointment(Date appointmentDate, Lawyer lawyer, Client client, String reason) {
		super();
		this.appointmentDate = appointmentDate;
		this.lawyer = lawyer;
		this.client = client;
		this.reason = reason;
	}

	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getAppoinmentId() {
		return appoinmentId;
	}

	public void setAppoinmentId(int appoinmentId) {
		this.appoinmentId = appoinmentId;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public Lawyer getLawyer() {
		return lawyer;
	}

	public void setLawyer(Lawyer lawyer) {
		this.lawyer = lawyer;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}
	
	
}
