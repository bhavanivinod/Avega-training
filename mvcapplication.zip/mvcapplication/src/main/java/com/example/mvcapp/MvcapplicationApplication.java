package com.example.mvcapp;

import java.util.HashSet;
import java.util.Set;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.example.mvcapp.model.Client;
import com.example.mvcapp.model.Roles;
import com.example.mvcapp.serviceImpl.ClientUserService;

@SpringBootApplication
public class MvcapplicationApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(MvcapplicationApplication.class, args);

		ClientUserService userService = (ClientUserService) context.getBean("ClientUserService");

//		 String firstName, String lastName, String phone, String street, String city, String state,
//			int zipCode, String password
//		 Client client = new Client("Aravindh", "Madasamy", "7871831959", "South Street", "Chennai", "TN", 600044, "admin");
//		 
//		 Set<Roles> roles = new HashSet<Roles> (); 
//		 roles.add(userService.getRoleById(1).get());
//		 client.setRoles(roles);
//		userService.addUser(client);
	}
	
}
